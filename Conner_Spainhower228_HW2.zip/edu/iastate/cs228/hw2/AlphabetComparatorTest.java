package edu.iastate.cs228.hw2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/**
 * @author Conner Spainhower
 * Test class for AlphabetComparator
 */

class AlphabetComparatorTest {

	@Test
	void test() {
		/*
		 * Gives the simulated ordering of letters and initializes comparators
		 */
		char[] ordering = {'c', 'a','t', 'g', 'd', 'o'};
		Alphabet test = new Alphabet(ordering);
		AlphabetComparator ope = new AlphabetComparator(test);
		String s = "cat";
		String t = "cat";
		/**
		 * Tests the compare method with multiple test cases
		 */
		assertEquals(0, ope.compare(t, s));
		String a = "cat";
		String b = "catherine";
		assertEquals(1, ope.compare(a, b));
		String c = "dog";
		String d = "cat";
		assertEquals(-1, ope.compare(c, d));
	}

}
