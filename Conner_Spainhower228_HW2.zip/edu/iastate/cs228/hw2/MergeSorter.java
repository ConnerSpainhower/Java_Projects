package edu.iastate.cs228.hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs merge sort
 * to sort the list.
 * 
 * @author Conner Spainhower
 */
public class MergeSorter extends Sorter
{
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException{
    // TODO
	  mergeSortRec(toSort, comp, 0, toSort.length() - 1);
  }

  private void mergeSortRec(WordList list, Comparator<String> comp, int start, int end)
  {
    // TODO
	  if (start == end || (end - start) < 2)
	      return;
	    int mid = (start + end) / 2;
	    
	    mergeSortRec(list, comp, start, mid);
	    mergeSortRec(list, comp, mid + 1, end);
	    merge(list, comp, start, mid, end);
	}
  
  /**
   * A custom method made to assist in the merging process
   * @param list is the provided WordList
   * @param comp is the provided comparator
   * @param start is where to begin
   * @param middle is where to merge the two arrays
   * @param end is where the end of the total array is
   */
  private void merge(WordList list, Comparator<String> comp, int start, int middle, int end) {
	  	int n = end - start + 1;
	  	Object[] values = new Object[n];

	    int fromValue = start;
	    int middleValue = middle + 1;
	    int index = 0;

	    while (fromValue <= middle && middleValue <= end) {
	      if (comp.compare(list.get(fromValue), list.get(middleValue)) < 0) {
	    	  values[index] = list.get(fromValue);
	    	  fromValue++;
	      } else {
	    	  values[index] = list.get(middleValue);
	    	  middleValue++;
	      }
	      index++;
	    }

	    while (fromValue <= middle) {
	    	values[index] = list.get(fromValue);
	    	fromValue++;
	    	index++;
	    }
	    while (middleValue <= end) {
	    	values[index] = list.get(middleValue);
	    	middleValue++;
	    	index++;
	    }

	    for (index = 0; index < n; index++) {
	    	list.set(start + index, values[index].toString());
	  }
  	}
}
