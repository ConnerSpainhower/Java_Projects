package edu.iastate.cs228.hw2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class QuickSorterTest {
/**
 * A test class to test QuickSorter
 * @author Conner Spainhower
 */
	@Test
	void test() {
		/*
		 * Gives the simulated wordlist
		 */
		String[] name = { "Hello","cat", "olleh", "dog", "doge", "empty"};
		
		WordList toSort = new WordList(name);
		/**
		 * Gives the simulated ordering of the letters
		 */
		char[] ordering = {'d', 'o','g','e', 'l', 'c', 't', 'a', 'H'};
		/**
		 * Creates the tester and initializes it
		 */
		Alphabet test = new Alphabet(ordering);
		AlphabetComparator comp = new AlphabetComparator(test);
		QuickSorter sorter = new QuickSorter();
		/**
		 * Runs the sorter and prints out the result
		 */
		sorter.sort(toSort, comp);
		
		for(String example : toSort.getArray()) {
			System.out.println(example);
		}
	}

}
