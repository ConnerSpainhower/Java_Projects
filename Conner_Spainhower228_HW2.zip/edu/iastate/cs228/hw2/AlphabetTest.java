package edu.iastate.cs228.hw2;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;
/**
 * A test class for Alphabet
 * @author Conner Spainhower
 *
 */
class AlphabetTest {

	@Test
	void test() throws FileNotFoundException {
		/**
		 * Gives the simulated ordering and wordlist
		 */
		char[] ordering = {'c', 'a','t'};
		Alphabet test = new Alphabet(ordering);
		Alphabet test2 = new Alphabet("10.alphabet.txt");
		/**
		 * Tests the isValid class
		 */
		assertEquals(true, test.isValid('c'));
		assertEquals(false, test.isValid('d'));
		/**
		 * Tests the getPosition class
		 */
		assertEquals(0, test.getPosition('c'));
		assertEquals(12, test.getPosition('-'));
	}

}
