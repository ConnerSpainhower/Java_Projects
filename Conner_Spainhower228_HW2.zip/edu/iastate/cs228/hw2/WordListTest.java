package edu.iastate.cs228.hw2;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

class WordListTest {
	/**
	 * A test for the WordList class
	 * @throws FileNotFoundException
	 * @author Conner Spainhower
	 */

	@Test
	void test() throws FileNotFoundException {
		String[] test = {"Hello", "olleH", "cat", "dog", "fish", "rock"};
		WordList bruh = new WordList(test);
		WordList bruh2 = new WordList("10.wordlist.txt");
		//WordList bruh3 = new WordList("100.wordlist.txt");
		//WordList bruh4 = new WordList("1000.wordlist.txt");
		//WordList bruh5 = new WordList("10000.wordlist.txt");
		//WordList bruh6 = new WordList("100000.wordlist.txt");
		//WordList bruh7 = new WordList("1000000.wordlist.txt");
		
		/**
		 * tests length()
		 */
		assertEquals(5, bruh.length());
		assertEquals(10, bruh2.length());
		//assertEquals(100, bruh3.length());
		//assertEquals(1000, bruh4.length());
		//assertEquals(10000, bruh5.length());
		//assertEquals(100000, bruh6.length());
		//assertEquals(1000000, bruh7.length());
		
		/**
		 * tests get()
		 */
		assertEquals("Hello", bruh.get(0));
		assertEquals("y11_1-|<m^<^_^T;0_m_,Tm", bruh2.get(1));
		
		/**
		 * tests set()
		 */
		bruh.set(0, "hello");
		assertEquals("hello", bruh.get(0));
		bruh2.set(0, "there");
		assertEquals("there", bruh2.get(0));
		
		/**
		 * tests swap()
		 */
		bruh.swap(0, 1);
		assertEquals("olleH", bruh.get(0));
		assertEquals("hello", bruh.get(1));
		bruh2.swap(0, 1);
		assertEquals("y11_1-|<m^<^_^T;0_m_,Tm", bruh2.get(0));
		assertEquals("there", bruh2.get(1));
		/**
		 * tests getArray()
		 */
		for(String example : bruh.getArray()) {
			System.out.println(example);
		}
		for(String example2 : bruh2.getArray()) {
			System.out.println(example2);
		}
		/**
		 * tests clone()
		 */
		System.out.println(bruh.clone());
		System.out.println(bruh2.clone());
	}

}
