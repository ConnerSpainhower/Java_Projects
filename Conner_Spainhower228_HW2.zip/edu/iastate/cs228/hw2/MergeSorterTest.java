package edu.iastate.cs228.hw2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MergeSorterTest {
/**
 * Tests the MergeSorter Class
 * @author Conner Spainhower
 */
	@Test
	void test() {
		/*
		 * Gives the simulated wordlist
		 */
		String[] name = { "Hel","cat", "oll", "dog", "log",  "loge", "empty"};
		
		WordList toSort = new WordList(name);
		/**
		 * Gives the simulated ordering of the letters
		 */
		char[] ordering = {'d', 'o','g','e', 'l', 'c', 't', 'a', 'H'};
		/**
		 * Creates the tester and initializes it
		 */
		Alphabet test = new Alphabet(ordering);
		AlphabetComparator comp = new AlphabetComparator(test);
		InsertionSorter sorter = new InsertionSorter();
		/**
		 * Runs the sorter and prints out the result
		 */
		sorter.sort(toSort, comp);
		
		for(String example : toSort.getArray()) {
			System.out.println(example);
		}
	}

}
