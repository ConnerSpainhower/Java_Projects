package edu.iastate.cs228.hw2;


import java.util.Comparator;


/**
 * An implementation of {@link Sorter} that performs quick sort
 * to sort the list.
 * 
 * @author Conner Spainhower
 */
public class QuickSorter extends Sorter
{
  @Override
  public void sort(WordList toSort, Comparator<String> comp) throws NullPointerException{
    // TODO
	  quickSortRec(toSort, comp, 0, toSort.length() - 1);
  }

  private void quickSortRec(WordList list, Comparator<String> comp, int start, int end){
    // TODO
	  if (start < end) {
	        int partitionIndex = partition(list, comp, start, end);
	 
	        quickSortRec(list, comp, start, partitionIndex-1);
	        quickSortRec(list, comp, partitionIndex + 1, end);
	    }
  }

  private int partition(WordList list, Comparator<String> comp, int start, int end){
    // TODO
	  int pivot = (start + end) / 2;
	  boolean finished = false;
	  while (!finished) {
		  while (comp.compare(list.get(start), list.get(pivot)) < 0) {
			  start += 1;
		  }
		  while (comp.compare(list.get(pivot), list.get(end)) < 0) {
			  end -= 1;
		  }
		  if (start >= end) {
			  finished = true;
		  }
		  else {
			  list.swap(start, end);
			  start += 1;
			  end -= 1;
		  }
	  }
			 
	return end;
  }
}
