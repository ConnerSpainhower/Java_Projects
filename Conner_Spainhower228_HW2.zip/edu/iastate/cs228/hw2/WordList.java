package edu.iastate.cs228.hw2;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


/**
 * A simple list of Strings.
 * 
 * @author Conner Spainhower
 */
public
class
WordList
  implements Cloneable
{
  /**
   * The array holding all of the elements of the list.
   */
  private
  String[]
  words;


  /**
   * Constructs and initializes the list to have exactly the same contents as
   * the given array.
   * 
   * @param contents
   *   the array with the contents of the new list
   * @throws NullPointerException
   *   if {@code contents} is {@code null}
   */
  public
  WordList(String[] contents)
    throws NullPointerException
  {
    // TODO
	  words = new String[contents.length - 1];
	  for(int i = 0; i < contents.length - 1; i++) {
		  words[i] = contents[i];
	  }
  }

  /**
   * Constructs and initializes the list by reading from the indicated file.
   * The file is read assuming that each line contains a word. The ordering in
   * the file is the order that will be used by the list.
   * 
   * @param filename
   *   the name of the file to read
   * @throws NullPointerException
   *   if {@code filename} is {@code null}
   * @throws FileNotFoundException
   *   if the file cannot be found
   */
  public
  WordList(String filename)
    throws NullPointerException,
           FileNotFoundException
  {
    // TODO
	  Scanner sc = new Scanner(new File(filename)).useDelimiter(",\\s*");
	  ArrayList<String> tokens = new ArrayList<String>();
	  while (sc.hasNext()) {
	      tokens.add(sc.nextLine());
	  }
	  words = tokens.toArray(new String[0]);
  }


  /**
   * Returns the number of elements in the list.
   * 
   * @return
   *   the number of elements in the list
   */
  public
  int
  length()
  {
    // TODO

    return words.length;
  }

  /**
   * Returns the element of the list at the indicated index.
   * 
   * @param idx
   *   the index of the element to retrieve
   * @return
   *   the element at the indicated index
   * @throws IndexOutOfBoundsException
   *   if {@code idx} is negative or greater than or equal to the length of
   *   the list
   */
  public
  String
  get(int idx)
    throws IndexOutOfBoundsException
  {
    // TODO

    return words[idx];
  }

  /**
   * Sets the element of the list at the indicated index to the given value.
   * 
   * @param idx
   *   the index of the element to set
   * @param newValue
   *   the new value of the element
   * @throws IndexOutOfBoundsException
   *   if {@code idx} is negative or greater than or equal to the length of the
   *   list
   */
  public
  void
  set(int idx, String newValue)
    throws IndexOutOfBoundsException
  {
    words[idx] = newValue;
  }

  /**
   * Swaps the indicated elements in the list.
   * 
   * @param idxA
   *   the index of one of the elements to swap
   * @param idxB
   *   the index of the other element to swap
   * @throws IndexOutOfBoundsException
   *   if either of {@code idxA} or {@code idxB} is negative or greater than or
   *   equal to the length of the list
   */
  public
  void
  swap(int idxA, int idxB)
    throws IndexOutOfBoundsException
  {
    // TODO
	  String temp = words[idxA];
	  words[idxA] = words[idxB];
	  words[idxB] = temp;
  }

  /**
   * Returns the array used by the list to store its elements.
   * 
   * @return
   *   the array used by the list to store its elements
   */
  public
  String[]
  getArray()
  {
    // TODO

    return words;
  }

  /**
   * Performs a deep copy of the list.
   */
  @Override
  public
  WordList
  clone()
  {
    /*
     * note: since Strings are immutable, you don't need to clone them
     */
    // TODO
	WordList copy = new WordList(words);

    return copy;
  }
}
