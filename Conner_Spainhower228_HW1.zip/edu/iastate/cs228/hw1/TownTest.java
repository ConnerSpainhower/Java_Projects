package edu.iastate.cs228.hw1;
import edu.iastate.cs228.hw1.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;
/**
 *  @author <<Conner Spainhower>>
 *
 */
class TownTest {

	@Test
	void test() throws FileNotFoundException {
		Town p = new Town(4, 5);
		
		assertEquals(5, p.getWidth());
		System.out.println();
		assertEquals(4, p.getLength());
		System.out.println();
		p.randomInit(5);
		System.out.println();
		p.toString();
	}

}
