package edu.iastate.cs228.hw1;

/**
 * 
 * @author <<Conner Spainhower>>
 *
 */
public abstract class TownCell {
	/**
	 * Creates a Town object
	 */
	protected Town plain;
	/**
	 * Creates an int used to track rows
	 */
	protected int row;
	/**
	 * Creates an int used to track columns
	 */
	protected int col;
	
	
	// constants to be used as indices.
	protected static final int RESELLER = 0;
	protected static final int EMPTY = 1;
	protected static final int CASUAL = 2;
	protected static final int OUTAGE = 3;
	protected static final int STREAMER = 4;
	
	public static final int NUM_CELL_TYPE = 5;
	
	//Use this static array to take census.
	public static final int[] nCensus = new int[NUM_CELL_TYPE];
/**
 * Constructor
 * @param p used for Town object
 * @param r used for row size
 * @param c used for column size
 */
	public TownCell(Town p, int r, int c) {
		plain = p;
		row = r;
		col = c;
	}
	
	/**
	 * Censuses all cell types in the 3 X 3 neighborhood
	 * Use who() method to get who is present in the 
	 *  
	 * @param counts of all customers
	 */
	public void census(int nCensus[]) {
		// zero the counts of all customers
		nCensus[RESELLER] = 0; 
		nCensus[EMPTY] = 0; 
		nCensus[CASUAL] = 0; 
		nCensus[OUTAGE] = 0; 
		nCensus[STREAMER] = 0;
		
		if(who() == State.CASUAL || who() == State.EMPTY || who() == State.OUTAGE || who() == State.RESELLER || who() == State.STREAMER) {
			for(int rowCount = row - 1; rowCount <= (row + 1); rowCount += 1) {
				for(int colCount = col - 1; colCount <= (col + 1); colCount += 1) {
					if((rowCount > 0) || (colCount > 0) || (rowCount <= row) || (colCount <= col)) {
						for(int i = 0; i < row; i++) {
							for(int j = 0; j < col; j++) {
								if (plain.grid[row][col].who() == State.RESELLER) {
									nCensus[RESELLER]++;
								}
								if (plain.grid[row][col].who() == State.CASUAL) {
									nCensus[CASUAL]++;
								}
								if (plain.grid[row][col].who() == State.EMPTY) {
									nCensus[EMPTY]++;
								}
								if (plain.grid[row][col].who() == State.OUTAGE) {
									nCensus[OUTAGE]++;
								}
								if (plain.grid[row][col].who() == State.STREAMER) {
									nCensus[STREAMER]++;
								}
							}
						}
					}
				}
			}
		}
		


	}

	/**
	 * Gets the identity of the cell.
	 * 
	 * @return State
	 */
	public abstract State who();

	/**
	 * Determines the cell type in the next cycle.
	 * 
	 * @param tNew: town of the next cycle
	 * @return TownCell
	 */
	public abstract TownCell next(Town tNew);
		
}


/**
 * @Casual is the constructor
 * @who is the identifier for the cell
 * @next gives the conditions for the next cell state
 */
class Casual extends TownCell{
	
	public Casual(Town p, int r, int c) {
		super(p, r, c);
	}
	
	public State who() {
		return State.CASUAL;
	}
	
	public TownCell next(Town tNew) {
		int count[] = new int [9];
		census(count);
		if(count[RESELLER] >= 1) {
			return new Outage(tNew, row, col);
		}
		else if(count[STREAMER] >= 1) {
			return new Streamer(tNew, row, col);
		}
		else if(count[EMPTY] <= 1 || count[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		}
		else if(count[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}
		else {
			return new Casual(tNew, row, col);
		}
	}

}

/**
 * @Streamer is the constructor
 * @who is the identifier for the cell
 * @next gives the conditions for the next cell state
 */
class Streamer extends TownCell{
	
	public Streamer(Town p, int r, int c) {
		super(p, r, c);
	}
	
	public State who() {
		return State.STREAMER;
	}
	
	public TownCell next(Town tNew) {
		int count[] = new int [9];
		census(count);
		if(count[RESELLER] >= 1) {
			return new Outage(tNew, row, col);
		}
		else if(count[OUTAGE] >= 1) {
			return new Empty(tNew, row, col);
		}
		else if(count[EMPTY] <= 1 || count[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		}
		else if(count[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}
		else {
			return new Streamer(tNew, row, col);
		}
	}
	
}

/**
 * @Reseller is the constructor
 * @who is the identifier for the cell
 * @next gives the conditions for the next cell state
 */
class Reseller extends TownCell{
	
	public Reseller(Town p, int r, int c) {
		super(p, r, c);
	}
	
	public State who() {
		return State.RESELLER;
	}
	
	public TownCell next(Town tNew) {
		int count[] = new int [9];
		census(count);
		if(count[CASUAL] <= 3) {
			return new Empty(tNew, row, col);
		}
		else if(count[EMPTY] >= 3) {
			return new Empty(tNew, row, col);
		}
		else if(count[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}
		else {
			return new Reseller(tNew, row, col);
		}
	}
	
}

/**
 * @Empty is the constructor
 * @who is the identifier for the cell
 * @next gives the conditions for the next cell state
 */
class Empty extends TownCell{
	
	public Empty(Town p, int r, int c) {
		super(p, r, c);
	}
	
	public State who() {
		return State.EMPTY;
	}
	
	public TownCell next(Town tNew) {
		int count[] = new int [9];
		census(count);
		if(count[EMPTY] <= 1 || count[OUTAGE] <= 1) {
			return new Reseller(tNew, row, col);
		}
		else if(count[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}
		else {
			return new Casual(tNew, row, col);
		}
	}
	
}

/**
 * @Outage is the constructor
 * @who is the identifier for the cell
 * @next gives the conditions for the next cell state
 */
class Outage extends TownCell{
	
	public Outage(Town p, int r, int c) {
		super(p, r, c);
	}
	
	public State who() {
		return State.OUTAGE;
	}
	
	public TownCell next(Town tNew) {
		int count[] = new int [9];
		census(count);
		if(count[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		}
		else {
			return new Empty(tNew, row, col);
		}
	}
	
}

