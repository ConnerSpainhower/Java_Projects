package edu.iastate.cs228.hw1;
import edu.iastate.cs228.hw1.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;
/**
 *  @author <<Conner Spainhower>>
 *
 */
class ResellerTest {

	@Test
	void test() throws FileNotFoundException { 
		Town p = new Town("src/ISP4x4.txt");
		Casual Test = new Casual(p, 4, 5);
		
		assertEquals("Reseller", Test.who());
		System.out.println();
		Test.next(p);
	}
}
