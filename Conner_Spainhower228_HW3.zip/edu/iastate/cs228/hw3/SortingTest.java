package edu.iastate.cs228.hw3;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ListIterator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SortingTest {

private StoutList<Integer> list;
	
	private ListIterator<Integer> iter;
	
	@BeforeEach
	void test() {
		list = new StoutList<Integer>(4);
		
		list.add(5);
		list.add(2);
		list.add(7);
		list.add(1);
		list.add(0);
		list.add(11);
		list.add(3);
		list.add(2);
		list.add(5);
		list.add(85);
		
		iter = list.listIterator();
	}
	
	@Test
	void testSortIncreasing() {
		System.out.println("Non-Decreasing order:");
		list.sort();
		System.out.println(list.toStringInternal(iter));
		System.out.println();
		assertEquals(list.toStringInternal(iter), "[(| 0, 1, 2, 2), (3, 5, 5, 7), (11, 85, -, -)]");
	}
	
	@Test
	void testSortDecreasing() {
		System.out.println("Non-Increasing order:");
		list.sortReverse();
		System.out.println(list.toStringInternal(iter));
		System.out.println();
		assertEquals(list.toStringInternal(iter), "[(| 85, 11, 7, 5), (5, 3, 2, 2), (1, 0, -, -)]");
	}
}
