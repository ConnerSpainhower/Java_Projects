package edu.iastate.cs228.hw3;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ListIterator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class addTest {

	private StoutList list;
	
	private ListIterator iter;

	/*
	 * Constructs defualt StoutList, which has nodeSize of 4 and empty list
	 */
	@BeforeEach
	void setUp() throws Exception {
		list = new StoutList();
	}

	
	@Test
	void testAdd1() {
		System.out.println("testAdd1");
		
		System.out.println(list.toStringInternal());
		list.add(1);
		System.out.println(list.toStringInternal());
		assertEquals("[(1, -, -, -)]", list.toStringInternal());
		
		System.out.println();
	}
	
	@Test
	void testAdd2() {
		System.out.println("testAdd2");
		
		System.out.println(list.toStringInternal());
		list.add(1);
		System.out.println(list.toStringInternal());
		list.add(2);
		System.out.println(list.toStringInternal());
		list.add(3);
		System.out.println(list.toStringInternal());
		list.add(4);
		System.out.println(list.toStringInternal());
		list.add(5);
		System.out.println(list.toStringInternal());
		assertEquals("[(1, 2, 3, 4), (5, -, -, -)]", list.toStringInternal());

		System.out.println();
	}
	
	@Test
	void testAdd3() {
		assertEquals(true, list.add(1));
	}

	@Test
	void testAddNull() {
		boolean isCaught = false;

		try {
			list.add(null);
		}
		catch (NullPointerException e) {
			isCaught = true;
		}
		
		assertEquals(true, isCaught);
	}
	
	@Test
	void testSize1() {
		list.add(1);
		assertEquals(1, list.size());
	}
	
	@Test
	void testSize2() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		assertEquals(5, list.size());
	}
	
	@Test
	void testSize3() {
		assertEquals(0, list.size());
	}
	
	@Test
	void testOutput() {
		System.out.println("testOutput");
		
		list = new StoutList(4);

		list.add(0);
		list.add(1);
		list.add(2);
		list.add(7);
		list.add(2);

		list.add(2);
		list.add(2);
		list.add(2);
		list.add(7);

		iter = list.listIterator();
		
		System.out.println(list.toStringInternal(iter));

		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		System.out.println(list.toStringInternal(iter));
	}

}
