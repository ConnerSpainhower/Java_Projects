package edu.iastate.cs228.hw3;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class StoutIteratorTest {
	
	private StoutList list;
	
	private Iterator iter;
	
	@BeforeEach
	void test() {
		list = new StoutList(2);
		
		list.add(0);
		list.add(1);
		list.add(2);
		
		iter = list.iterator();
	}
	
	//Tests if next() will scan first element in first node
	@Test
	void testNext1() {
		Object data = iter.next();
		System.out.println(list.toStringInternal());
		System.out.println(data);
		assertEquals(0, data);
	}
	
	//Make's sure next() updates cursor appropriately for element in next node
	@Test
	void testNext2() {
		Object data = iter.next();
		data = iter.next();
		data = iter.next();
		System.out.println(data);
		assertEquals(2, data);
	}
	
	//tests if hasNext() will return true since element still left in list
	@Test
	void testhasNext1() {
		assertEquals(true, iter.hasNext());
	}
	
	//Tests if hasNext() will return false once all elements are scanned with next()
	@Test
	void testhasNext2() {
		Object data = iter.next();
		data = iter.next();
		data = iter.next();
		assertEquals(false, iter.hasNext());
	}
	
	//Tests if hasNext() will return false if only dummy nodes in list
	@Test
	void testhasNext3() {
		list = new StoutList();
		iter = list.iterator();
		assertEquals(false, iter.hasNext());
	}

}
