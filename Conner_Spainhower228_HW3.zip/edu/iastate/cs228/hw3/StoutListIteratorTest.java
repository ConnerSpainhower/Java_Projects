package edu.iastate.cs228.hw3;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class StoutListIteratorTest {

	private StoutList list;
	
	private ListIterator iter;
	
	@BeforeEach
	void test() {
		list = new StoutList(2);
		
		list.add(0);
		list.add(1);
		list.add(2);
		
		iter = list.listIterator();
	}
	
	//Tests to see if hasNext returns true after list was made
	@Test
	void testHasNext1() {
		assertEquals(true, iter.hasNext());
	}
	
	//Tests to check that hasNext is false when iterator is out of next elements
	@Test
	void testHasNext2() {
		iter.next();
		iter.next();
		iter.next();
		assertEquals(false, iter.hasNext());
	}
	
	//Tests if hasPrevious returns false after list was made, since starting in first node after head
	@Test
	void testHasPrevious1() {
		assertEquals(false, iter.hasPrevious());
	}
	
	//Checks to make sure hasPrevious is true when no next elements
	@Test
	void testHasPrevious2() {
		iter.next();
		iter.next();
		iter.next();
		assertEquals(true, iter.hasPrevious());
	}
	
	@Test
	void testPosConstructor() {
		list = new StoutList(2);
		
		list.add(0);
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		
		System.out.println(list.toStringInternal(iter));
		
		iter = list.listIterator(2);
		
		assertEquals(iter.nextIndex(), 2);
		assertEquals(iter.previousIndex(), 1);
		assertEquals(iter.hasNext(), true);
		assertEquals(iter.hasPrevious(), true);
	}
	
	@Test
	void testNextThenPrevious() {
		iter.next();
		iter.next();
		iter.next();
		assertEquals(2, iter.previous());
		assertEquals(2, iter.next());
	}
	
	@Test
	void testSet1() {
		boolean isCaught = false;
		try {
			iter.set(3);
		}
		catch(IllegalStateException e) {
			isCaught = true;
		}
		assertEquals(isCaught, true);
	}
	
	@Test
	void testSet2() {
		iter.next();
		iter.set(4);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(4, 1), (2, -)]", list.toStringInternal());
	}
	
	@Test
	void testSet3() {
		System.out.println();
		System.out.println("testSet3");
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.set(4);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(0, 1), (4, -)]", list.toStringInternal());
		System.out.println();
	}
	
	@Test
	void testSet4() {
		iter.next();
		iter.next();
		iter.next();
		iter.previous();
		iter.set(4);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(0, 1), (4, -)]", list.toStringInternal());
	}
	
	@Test
	void testIterAddCases() {
		System.out.println();
		System.out.println("testIterAddCases");
		list = new StoutList(4);
		assertEquals(list.toStringInternal(), "[]");
		
		/*
		 * if the list is empty, create a new node and put X at offset 0
		 */
		list.add(1);
		iter = list.listIterator();
		System.out.println(list.toStringInternal(iter));
		assertEquals(list.toStringInternal(iter), "[(| 1, -, -, -)]");
		
		/*
		 * otherwise if there is space in node n, put X in node n at offset off, shifting array elements as necessary
		 */
		iter.add(2);
		System.out.println(list.toStringInternal(iter));
		assertEquals(list.toStringInternal(iter), "[(2, | 1, -, -)]");
		
		iter.add(3);
		iter.add(4);
		System.out.println(list.toStringInternal(iter));
		iter.add(5);
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		iter.add(6);
		System.out.println(list.toStringInternal(iter));
		/*
		 * if n has a predecessor which has fewer than M elements (and is not the head) and offset = 0, put X in n�s predecessor
		 */
		assertEquals(list.toStringInternal(iter), "[(2, 3, 6, -), (| 4, 5, 1, -)]");

		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.add(7);
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		/*
		 * Split operation, if off <= nodesize / 2, put X in node n at offset off
		 */
		iter.add(8);
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		assertEquals(list.toStringInternal(iter), "[(2, 3, 6, -), (4, | 8, 7, -), (5, 1, -, -)]");
		
		iter.next();
		System.out.println(list.toStringInternal(iter));
		iter.add(9);
		System.out.println(list.toStringInternal(iter));
		iter.add(10);
		System.out.println(list.toStringInternal(iter));
		/*
		 * Split operation, if off <= nodesize / 2, put X in node n at offset off - nodesize / 2
		 */
		assertEquals(list.toStringInternal(iter), "[(2, 3, 6, -), (4, 8, -, -), (9, 10, | 7, -), (5, 1, -, -)]");

		
		System.out.println();
	}
	
	@Test
	void testIterRemoveCases() {
		System.out.println();
		System.out.println("testIterRemoveCases");
		list = new StoutList(4);
		System.out.println(list.toStringInternal());
		assertEquals(list.toStringInternal(), "[]");
		
		list.add(1);
		iter = list.listIterator();
		
		System.out.println(list.toStringInternal(iter));
		iter.next();
		System.out.println(list.toStringInternal(iter));
		// if the node n containing X is the last node and has only one element, delete it;
		iter.remove();
		System.out.println(list.toStringInternal(iter));
		assertEquals(list.toStringInternal(iter), "[]");
		
		
		iter.add(2);
		System.out.println(list.toStringInternal(iter));
		iter.add(3);
		System.out.println(list.toStringInternal(iter));
		iter.add(4);
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		iter.remove();
		System.out.println(list.toStringInternal(iter));
		//if n is the last node (thus with two or more elements),  remove X from n, shifting elements as necessary;
		assertEquals("[(2, | 4, -, -)]", list.toStringInternal(iter));
		iter.add(5);
		iter.add(6);
		iter.add(7);
		iter.previous();
		iter.remove();
		iter.previous();
		iter.previous();
		System.out.println(list.toStringInternal(iter));
		//Tests full merge
		iter.remove();
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(2, | 6, 4, -)]", list.toStringInternal(iter));
		iter.add(8);
		iter.add(9);
		iter.add(10);
		iter.add(11);
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		iter.previous();
		iter.remove();
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		iter.remove();
		System.out.println(list.toStringInternal(iter));
		iter.previous();
		//Tests mini merge
		iter.remove();
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(2, | 11, -, -), (6, 4, -, -)]", list.toStringInternal(iter));
		
		System.out.println();
	}
	
	@Test
	void testSetCases() {
		System.out.println();
		System.out.println("testSetCases");
		list = new StoutList(4);
		System.out.println(list.toStringInternal());
		assertEquals(list.toStringInternal(), "[]");
		
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		iter = list.listIterator();
		System.out.println(list.toStringInternal(iter));
		
		System.out.println(iter.next()); //Prints the call to make sure you are changing the element last returned by next/prev call
		iter.set(5);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(5, | 2, 3, 4)]", list.toStringInternal(iter));
		
		System.out.println(iter.previous());
		iter.set(6);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(| 6, 2, 3, 4)]", list.toStringInternal(iter));
		
		iter.next();
		System.out.println(iter.next());
		iter.set(7);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(6, 7, | 3, 4)]", list.toStringInternal(iter));
		
		iter.next();
		System.out.println(iter.previous());
		iter.set(8);
		System.out.println(list.toStringInternal(iter));
		assertEquals("[(6, 7, | 8, 4)]", list.toStringInternal(iter));
	}

}
