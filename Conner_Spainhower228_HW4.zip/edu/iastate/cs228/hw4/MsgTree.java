package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

/**
 * 
 * @author cspainho
 *
 */
public class MsgTree {
	
	public char payloadChar = '^';
	public MsgTree left;
	public MsgTree right;
	private MsgTree root;
	
	
	//Need static char idx to the tree string for recursive solution
	private static int staticCharIdx = -1;
	
	/**
	 * A constructor to create a tree
	 * @param encodingString - the string to base the tree off of
	 */
	public MsgTree(String encodingString){
		staticCharIdx++;
		if(encodingString.charAt(staticCharIdx) == '\0') {
			if(encodingString.charAt(staticCharIdx) == '^') {
				preOrder(left);
				left = new MsgTree(encodingString);
			}
			preOrder(right);
			right = new MsgTree(encodingString);
		}
	}
	
	/**
	 * A method to assist with the preOrder traversal process
	 * @param node - the beginning node to start traversing
	 */
	private void preOrder(MsgTree node) {
		if (node == null) { 
            return; 
        }
		
		Stack<MsgTree> tempStack = new Stack<MsgTree>(); 
        tempStack.push(root);
        
        while (tempStack.empty() == false) { 
        	  
            // Pop the top item from stack
            MsgTree mynode = tempStack.peek();
            tempStack.pop(); 
  
            // Push right and left children of the popped node to stack 
            if (mynode.right != null) { 
                tempStack.push(mynode.right); 
            } 
            if (mynode.left != null) { 
                tempStack.push(mynode.left); 
            } 
        } 
	}
	

	/**
	 * A constructor to create a MsgTree with no children
	 * @param payloadChar - the starting node char
	 */
	public MsgTree(char payloadChar){
		left = right = null;
		this.payloadChar = payloadChar;
	}
	
	/**
	 * Method to print out all the chars in the message and what their codes were
	 * @param root - the beginning of the tree to traverse to find the codes
	 * @param code - to store the codes to print out
	 */
	public static void printCodes(MsgTree root, String code){
		if(root.payloadChar == '^') {
			if(root.left == null) {
				code.concat("0");
				printCodes(root.left, code);
			}
			if(root.right == null) {
				code.concat("1");
				printCodes(root.right, code);
			}
			
		}else {
			System.out.println(root.payloadChar + "\t" + code);
		}
	}
	/**
	 * Method decoding the string msg
	 * @param codes - the codes used to represent the chars in the message
	 * @param msg - the message given to us to decode
	 */
	public static void decode(MsgTree codes, String msg) {
		MsgTree root = codes;
		root.preOrder(root);
		if(root.left.payloadChar == '^' && root.right.payloadChar == '^') {
			for(int i = 0; i < msg.length(); i++) {
				char c = msg.charAt(i);
				if(c == '0') {
					codes.left.payloadChar = c;
				}
				if(c == '1') {
					codes.right.payloadChar = c;
				}
			}
		}
		
		printCodes(codes, msg);
		System.out.print("\t");
		decode(codes, msg);
	}
	
	public static void main(String [] args) {
		MsgTree bruh = null;
		String encodedString = null;
		try {
		File myFile = new File("dadcarb.arch");
		Scanner scan = new Scanner(myFile);
		Scanner scan2 = new Scanner(myFile);
		scan.nextLine();
		if(scan.nextLine().contains("\n")) {
			scan.nextLine();
		}
		scan2.nextLine();
		
		scan.close();
		scan2.close();
		String treeString = scan.toString();
		
		encodedString = scan2.toString();
		bruh = new MsgTree(treeString);
		
		}catch (FileNotFoundException e) {
			System.out.println("File not found");
			e.printStackTrace();
		}
		
		
		System.out.println("Character" + "\t" + "Code" );
		System.out.println("--------------------------");
		//printCodes(bruh, encodedString);
		decode(bruh, encodedString);
	}
}
